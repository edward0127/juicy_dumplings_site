module Admin::OpeningHoursHelper
end
