class ApplicationMailer < ActionMailer::Base
  default from: ENV.fetch("MAIL_FROM", "no-reply@juicydumplings.example")
  layout "mailer"
end
